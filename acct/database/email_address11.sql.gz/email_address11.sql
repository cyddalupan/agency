-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 21, 2017 at 10:33 PM
-- Server version: 5.5.51-38.2
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `property_accounting`
--

-- --------------------------------------------------------

--
-- Table structure for table `email_address11`
--

CREATE TABLE IF NOT EXISTS `email_address11` (
  `exp_id` int(11) NOT NULL,
  `email_address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `agent_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `app_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `date_med` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `findings` text COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `receivable` double NOT NULL,
  `amount_paid` double NOT NULL,
  `date_paid` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `date_release` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `exp_remarks` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `exp_status` int(11) NOT NULL,
  `currency` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `exp_type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email_created` datetime NOT NULL,
  `email_updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email_address11`
--
ALTER TABLE `email_address11`
  ADD PRIMARY KEY (`exp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email_address11`
--
ALTER TABLE `email_address11`
  MODIFY `exp_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
