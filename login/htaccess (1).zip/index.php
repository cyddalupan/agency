<!DOCTYPE html>
<html>
<head>
<style>
body{
font-family:calibri;
background:#F5F5F5;
}
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 36px;
  margin: 4px 2px;
  cursor: pointer;
  width:100%;
}

.button1 {border-radius: 2px;}
.button2 {border-radius: 4px;}
.button3 {border-radius: 8px;}
.button4 {border-radius: 12px;}
.button5 {border-radius: 50%;}
</style>
</head>
<body>


</br></br></br></br>

<div style="width:80%;margin:0 auto">



<a href="https://recruitment-portal.net/jinhel/admin/signin" class="button"   STYLE="BACKGROUND:LIGHTBLUE;HEIGHT:280PX;WIDTH:250PX;text-align:center;font-size:42px;color:white;font-weight:bold">
<img src="user.png" style="height:220px"> </br>
AGENCY </a>

<a href="https://recruitment-portal.net/jinhel/employer/signin" class="button"   STYLE="BACKGROUND:LIGHTBLUE;HEIGHT:280PX;WIDTH:250PX;text-align:center;font-size:42px;color:white;font-weight:bold">

<img src="admin.jpeg" style="height:220px"></br>
FRA</a>



<a href="https://recruitment-portal.net/jinhel/acct/production" class="button" STYLE="BACKGROUND:lightgreen;color:black;HEIGHT:280PX;WIDTH:250PX;text-align:center;font-size:42px;color:white;font-weight:bold">
<img src="accounting.png" style="height:220px"></br>
ACCOUNTING</a>


</div>

</body>
</html>
