<?php
$con=mysql_connect('localhost','injazman_injaz88','gbKtAK6yO8$k')or die ('cannot connect');
mysql_select_db('injazman_sample',$con);
?>
