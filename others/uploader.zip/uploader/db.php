<?php
$conn=mysqli_connect("localhost","concept_user","l_Gu0.Fe^f!O") or die("Could not connect");
mysqli_select_db($conn,"concept_phil") or die("could not connect database");

?>

</br></br></br>
<h1 STYLE="text-align:Center;color:lightblue">TEST PHILCANGCO PASAY DATABASE</h1>