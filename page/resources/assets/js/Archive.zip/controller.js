/**
 * Main JavaScript File
 * Author: Cyd Dalupan (cydmdalupan@gmail.com)
 */

var myApp = angular.module('myApp',[]);
