/*
 * simple remove dash on string function
 */
function remove_dash(str){
	return str.replace(/-/g, "");
}